import java.awt.event.*;
import java.util.*;

public class EcouteurFleche implements ActionListener{
	//attributs
	public int ligne;
	public FenetreJeu fen;
	
	//constructeur
	public EcouteurFleche(FenetreJeu fen, int i) {
		this.fen = fen;
		ligne = i;
	}
	
	//joue dans la ligne choisie
    public void actionPerformed(ActionEvent e){
		this.fen.jouer(this.ligne);
    }
    
}
