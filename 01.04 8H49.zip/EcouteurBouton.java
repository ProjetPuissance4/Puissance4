import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.*;
import java.awt.event.*;
import java.util.*;

public class EcouteurBouton implements ActionListener {
	private FenetreAccueil fen;
	private int i;
	private String color;
	
	
	public EcouteurBouton(FenetreAccueil fen, int i, String color) {
		this.fen= fen;
		this.i=i;
		this.color = color;
	}
	
	public void actionPerformed(ActionEvent e) {
		Pion p1 = new Pion(color, i);
		fen.j1.setPion(p1);
		fen.supprimeBouton(i);

	
	} 
	
	
	}
	
