public class P4 {
	
	public static void main (String[] args) {
		
		FenetreJeu f = new FenetreJeu();
	}
}
