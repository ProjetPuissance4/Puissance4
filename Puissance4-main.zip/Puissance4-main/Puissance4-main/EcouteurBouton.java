import java.awt.event.*;
import java.util.*;

public class EcouteurBouton implements ActionListener {
	private FenetreAccueil fen;
	
	public EcouteurBouton(FenetreAccueil fen) {
		this.fen= fen;
	}
	public void actionPerformed(ActionEvent e) {
	
	} 
	
	
	}
	
