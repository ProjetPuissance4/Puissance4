public class Pion {     
	public String couleur ;     
	
	public Pion (String c){
		this.couleur=c;
	}
	
}



