public class TestAccueil {
	
	public static void main(String[] a) {
		new FenetreAccueil();
	}
}

	
