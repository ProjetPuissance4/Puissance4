import java.awt.event.*;
import java.util.*;

public class EcouteurJouer implements ActionListener{
	private FenetreJeu fen;
	
 public void Jouer{
 
 }

 public void fin() {
 
 }
}
