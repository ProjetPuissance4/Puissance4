import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;


public class FenetreVictoire extends JFrame {
	
	//Attributs
	private JLabel titre; 
	private JPanel pane;
	private JLabel image;
    private JPanel affichageTemps;
    private JPanel tout;
    
    
    private static PrintWriter texteTemps;
    private int[][] meilleurTemps = new int[3][3];
    private JLabel meilleurTemps1;
    private JLabel meilleurTemps2;
    private JLabel meilleurTemps3;
	
	
	//Constructeur
	public FenetreVictoire(FenetreJeu fen) {
		
		super("Victoire");
        tout = new JPanel();
        tout.setLayout(null);
        tout.setBounds(0,0,500,1000);
		titre = new JLabel("VICTOIRE !!!!");
		
		//Changement de police
		titre.setFont(new Font("Elephant", Font.BOLD, 48));
        titre.setBounds(0,0,500,75);
        tout.add(titre);
		
		//Création du visuel 
		pane = new JPanel();
        pane.setBounds(0,100,500,160);
        
		image = new JLabel( new ImageIcon( "feuxartifices.gif"));
		
		pane.add(image);
        tout.add(pane);
        
        ArrayList <Long> listeTemps = new ArrayList();
        try {
            //on stocke les valeurs précédentes dans la liste
            Scanner sc = new Scanner(new File ("Chrono.txt"));
            while (sc.hasNext()){
				listeTemps.add(Long.parseLong(sc.nextLine()));
			}
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        //on ajoute la dernière
        listeTemps.add(fen.getT().getTempsFin());
        //on écrit dans notre .txt tout les temps
        try {
            texteTemps =new PrintWriter ("Chrono.txt");
            
            for(Long s:listeTemps){
                texteTemps.println(s);               
            }
            texteTemps.close();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        
        //on cherche les trois meilleurs temps puis on les ajoute a notre fenêtre
        Collections.sort(listeTemps);
        
        affichageTemps = new JPanel(null);
        affichageTemps.setBounds(0,160,1000,1000);
        
        String msg ="";
        int j =0;
        int i =0;
        while ( i<3 && j<listeTemps.size()){
			long tempsFin=listeTemps.get(j);
			int heureFin=(int) (tempsFin/3600000);
			if (heureFin!=0){
				tempsFin=tempsFin-heureFin*3600000;
			}else{
				heureFin=0;
			}
			int minuteFin=(int) (tempsFin/60000);
		
			if (minuteFin!=0){
				tempsFin=tempsFin-minuteFin*60000;
			}else{
				minuteFin=0;
			}
			int secondeFin=(int) (tempsFin/1000);
			
			msg="" +heureFin+":"+minuteFin+":"+secondeFin;
            if(i==0){
                meilleurTemps[i][0] = heureFin;
                meilleurTemps[i][1] = minuteFin;
                meilleurTemps[i][2] = secondeFin;
                i++;
                meilleurTemps1=new JLabel ("Premier meilleur temps    "+msg);
                meilleurTemps1.setBounds(20,100,500,40);
                affichageTemps.add(meilleurTemps1);
                
            }if(i==1 && !(heureFin== meilleurTemps[0][0] && minuteFin== meilleurTemps[0][1] && secondeFin==meilleurTemps[0][2]) ){
                meilleurTemps[i][0] = heureFin;
                meilleurTemps[i][1] = minuteFin;
                meilleurTemps[i][2] = secondeFin;
                i++;
                meilleurTemps2=new JLabel ("Deuxième meilleur temps  "+msg);
                meilleurTemps2.setBounds(20,140,500,40);
                affichageTemps.add(meilleurTemps2);
                
            }if(i==2 && (heureFin!= meilleurTemps[1][0] || minuteFin!= meilleurTemps[1][1] || secondeFin!=meilleurTemps[1][2] ) && !(heureFin== meilleurTemps[0][0] && minuteFin== meilleurTemps[0][1] && secondeFin==meilleurTemps[0][2])){
                meilleurTemps[i][0] = heureFin;
                meilleurTemps[i][1] = minuteFin;
                meilleurTemps[i][2] = secondeFin;
                i++;
                meilleurTemps3=new JLabel ("Troisième meilleur temps  "+msg);
                meilleurTemps3.setBounds(20,180,500,40);
                affichageTemps.add(meilleurTemps3);
            }
            j++;
            
		}
        tout.add(affichageTemps);
        add(tout);
		setVisible(true); 
		this.setSize(500,500);
		
	}
}

		
	
