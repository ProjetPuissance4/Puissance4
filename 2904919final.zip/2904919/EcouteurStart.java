import java.awt.event.*;
import java.util.*;

public class EcouteurStart implements ActionListener {
	//attributs
	private FenetreAccueil fen;
	
	//constructeur
	public EcouteurStart(FenetreAccueil fen) {
		this.fen= fen;
	}
	
	//lance le jeu
	public void actionPerformed(ActionEvent e) {
		fen.j1.setNom(fen.getNom1());
		if (fen.getNom1().equals(fen.getNom2())) {
			fen.j2.setNom(fen.getNom2()+"bis");
		}
		else {
			fen.j2.setNom(fen.getNom2());
		}
		if ( fen.condition() ) {
			FenetreJeu f = new FenetreJeu(fen, fen.j1, fen.j2) ; 		
			fen.fermeFen();
			f.getTemps();
		}

	}
}

