import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.*;
import java.lang.*;
import java.lang.Thread;
import java.util.concurrent.TimeUnit;
import java.lang.Object.*;


public class FenetreJeu extends JFrame {
	
	public String[][] cases;
	public JButton[] flechesJeu = new JButton[7];
	public JPanel cadre;
	public JLabel haut;
	public boolean demarrer;
	public JLabel timer;
	public int[] tabJeu;
	public int nbCoup;
	public FenetreAccueil fAccueil;
	public JLabel[][] grille;
	public Joueur[] joueur;
	public ImageIcon fleche;
	public boolean etat;
	public int recherche;
	public int actuel;
	public long tempsEcouleDepuis;
	public Timer timerJeu;
	public int col; //colonne en cours
	public JPanel blanc;
	public String typeVictoire;
	Temps t= new Temps();
	
	
	public FenetreJeu(FenetreAccueil f, Joueur j1, Joueur j2) {
		
		super("Puissance 4");
		
		fAccueil = f;
		nbCoup = 0;
		joueur = new Joueur[]{j1 , j2};
		this.setLayout(null);
		tabJeu = new int[]{0,0,0,0,0,0,0};
		demarrer = false;
		cases = new String[7][6];
		for (int i = 0 ; i < 7 ; i++) {
			for(int j = 0; j < 6 ; j++) {
				cases[i][j] = "blanc";
			}
		}
		
		grille = new JLabel[2][21];
		for (int i = 0; i < 2 ; i++ ) {
			for(int j = 0; j < 21 ; j++) {
				grille[i][j] = new JLabel(joueur[i].getPion().getImage());
				grille[i][j].setSize(100,100);
			}
		}
		fleche = new ImageIcon("fleche.png");
		setLocationRelativeTo(null);
		
		
		
		

		//Bouton des flèches, pour jouer
		for(int i = 0; i < 7; i++) {
			flechesJeu[i] = new JButton("jouer à la ligne "+i, fleche);
			flechesJeu[i].addActionListener(new EcouteurFleche((this), i));
			flechesJeu[i].setLocation(290+i*100,790);
			flechesJeu[i].setSize(100,100);
			this.add(flechesJeu[i]);
		}
		//Texts du haut
		haut = new JLabel("C'est à "+joueur[nbCoup%2].getNom()+" de jouer ! ");
		haut.setFont(new Font("Elephant", Font.BOLD, 20));
		haut.setLocation(450,50);
		haut.setSize(800,50);
		this.add(haut);
		
		JLabel score1 = new JLabel(""+joueur[0].getPion().getCouleur());
		score1.setFont(new Font("Elephant", Font.BOLD, 20));
		score1.setSize(100,100);
		score1.setLocation(100, 300);
		this.add(score1);
		
		JLabel score11 = new JLabel("  "+joueur[0].getScore());
		score11.setFont(new Font("Elephant", Font.BOLD, 20));
		score11.setSize(100,100);
		score11.setLocation(100, 350);
		this.add(score11);
		
		JLabel score2 = new JLabel(""+joueur[1].getPion().getCouleur());
		score2.setFont(new Font("Elephant", Font.BOLD, 20));
		score2.setSize(100,100);
		score2.setLocation(1150, 300);
		this.add(score2);

		JLabel score22 = new JLabel("  "+joueur[1].getScore());
		score22.setFont(new Font("Elephant", Font.BOLD, 20));
		score22.setSize(100,100);
		score22.setLocation(1150, 350);
		this.add(score22);
		
		timerJeu = new Timer(20, new EcouteurTimerJeu(this));
		
		
		
		blanc = new JPanel();
		blanc.setSize(700,600);
		blanc.setLocation(290,160);
		blanc.setBackground(Color.WHITE);
		//this.add(blanc);
		
		
		//this.setBackground(Color.WHITE);
		this.validate();
		this.repaint();
		this.setSize(1500,1500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	public void paint(Graphics g) {
		super.paint(g);
		g.drawLine(1000,200,1000,800);
		for (int i = 0; i <= 6 ; i++ ) {
			g.drawLine(300+i*100,200,300+i*100,800);
			g.drawLine(300,200+i*100,1000,200+i*100);
		}
	}
	
		
	public void showfile() throws java.io.IOException {
		
	}
	
	public void startTimer() {
		
	}
	
	public void jouer(int i) {
		
		this.col = i;
		
		enleverBoutons();
		
		if ( nbCoup == 0 ) {
			this.startTimer();
		}
		
		if (tabJeu[col] == 6) {
			this.remove(flechesJeu[col]);
		}
		
		cases[col][tabJeu[col]] =  joueur[nbCoup%2].getPion().getCouleur();
		
		
		grille[nbCoup%2][nbCoup].setLocation(290+col*100,160);
		this.add(grille[nbCoup%2][nbCoup]);
		recherche = 160 + (50 - 10 * tabJeu[col]) * 10 ;
		actuel = 160;
		etat = true;
		tabJeu[col]++;
		timerJeu.start();
		validate();
		repaint();
		
	}
	
	
	public boolean testVictoire(){
		boolean test=false;
		
		if(testLigne() == true || testColonne() == true || testDiagoDroite() == true || testDiagoGauche() == true ){
			test=true;
			System.out.println("victoire");
		}
		return test;
			
	}
	
	public boolean testLigne() {
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		for(int i = 0; i < 7; i++) {
			if( cases[i][tabJeu[col]-1].equals(c)) {
				compteur++;
			}
			
			else {
				compteur = 0;
			}
			
			
			
			if( compteur == 4) {
				typeVictoire = "ligne";
				break;
			}
		}
		return (compteur == 4);
	}
	
	public boolean testColonne() {
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		for(int i = 0; i < 6; i++) {
			if( cases[col][i].equals(c)) {
				compteur++;
			}
			
			else {
				compteur = 0;
			}
			
			
			
			if( compteur == 4) {
				typeVictoire = "colonne";
				break;
			}
		}
		return (compteur == 4);
	}
	
	public boolean testDiagoGauche() {
		int co = col;
		int l = tabJeu[col] - 1;
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		while( co != 6 && l != 0) {
			System.out.println("salut");
			co++;
			l--;
		}
		
		for(int i = 0 ; i <  6 ; i++) {
			try {
				if( cases[co-i][l+i].equals(c)) {
					compteur++;
				}
			
				else {
					compteur = 0;
				}
			
			
			
				if( compteur == 4) {
					typeVictoire = "dgauche";
					break;
				}
			}
			
			catch(Exception ex) {
				System.out.print("");
			}
		}
		return (compteur == 4);
	}
	
	public boolean testDiagoDroite() {
		int co = col;
		int l = tabJeu[col] - 1;
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		while( co !=  0 && l != 0) {
			System.out.println("salut");
			co--;
			l--;
		}
		
		for(int i = 0 ; i <  6 ; i++) {
			try {
				if( cases[co+i][l+i].equals(c)) {
					compteur++;
				}
			
				else {
					compteur = 0;
				}
			
			
			
				if( compteur == 4) {
					typeVictoire = "dgauche";
					break;
				}
			}
			
			catch(Exception ex) {
				System.out.print("");
			}
		}
		return (compteur == 4);
	}
	
	public void victoire() {
		enleverBoutons();
		
		joueur[nbCoup%2].addVic();
		haut.setText("BRAVO A "+joueur[nbCoup%2].getNom()+" POUR SA VICTOIRE !!");
		
		JButton rejouer = new JButton("REJOUER");
		JButton quitter = new JButton("QUITTER");
		
		rejouer.setSize(200,30);
		quitter.setSize(200,30);
		
		rejouer.setFont(new Font("Elephant", Font.BOLD, 20));
		quitter.setFont(new Font("Elephant", Font.BOLD, 20));
		
		rejouer.setLocation(400, 790);
		quitter.setLocation(700, 790);
		
		rejouer.addActionListener(new EcouteurFin((this), true));
		quitter.addActionListener(new EcouteurFin((this), false));
		
		this.add(rejouer);
		this.add(quitter);
	}
	
	public static void wait(int ms) {
										
		try {
		
			Thread.sleep(ms);
        
		}
    
		catch(InterruptedException ex) {
		
			Thread.currentThread().interrupt();
		}
	}
	
	public boolean getEtat() {
		return etat;
	}
	
	public void pion() {
		if (actuel < recherche) {
			actuel = actuel + 10;
			this.remove(grille[nbCoup%2][nbCoup]);
			grille[nbCoup%2][nbCoup].setLocation(290+col*100,actuel);
			this.add(grille[nbCoup%2][nbCoup]);
			validate();
			repaint();
		}

		else {
			timerJeu.stop();
			mettreBoutons();
			if (tabJeu[col] == 6) {
				this.remove(flechesJeu[col]);
			}
		
			if (!testVictoire()) {
				nbCoup++;
				haut.setText("C'est à "+joueur[nbCoup%2].getNom()+" de jouer ! ");
			}
		
			else if (testVictoire()) {
				this.victoire();
			}
		}
	}
	
	public void mettreBoutons() {
		for(int i = 0 ; i < 7 ; i++) {
			if (tabJeu[i] != 6) {
				this.add(flechesJeu[i]);
			}
		}
		validate();
		repaint();
	}
	
	public void enleverBoutons() {
		for(int i = 0; i < 7 ; i++) {
			this.remove(flechesJeu[i]);
		}
	}
	
	public void getTemps(){
        //Temps t= new Temps();
        JPanel chrono = new JPanel();
        chrono=t.getPanel();
        chrono.setBounds(500, 20, 200, 40);
        this.add(chrono);
        t.start();
        this.validate();
        this.repaint();
    }
	
}
		





