import java.awt.event.*;
import java.util.*;

public class EcouteurFleche implements ActionListener{
	
	public int ligne;
	public FenetreJeu fen;
	
	
	public EcouteurFleche(FenetreJeu fen, int i) {
		this.fen = fen;
		ligne = i;
	}
	
    public void actionPerformed(ActionEvent e){
		this.fen.jouer(this.ligne);
    }
    
}
