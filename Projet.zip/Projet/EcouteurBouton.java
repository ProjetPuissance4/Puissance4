import java.awt.event.*;
import java.util.*;

public class EcouteurBouton implements ActionListener {
	private FenetreAccueil fen;
	private int i;
	
	public EcouteurBouton(FenetreAccueil fen, int i) {
		this.fen= fen;
		this.i=i;
	}
	public void actionPerformed(ActionEvent e) {
		fen.supprimeBouton(i);

	
	} 
	
	
	}
	
