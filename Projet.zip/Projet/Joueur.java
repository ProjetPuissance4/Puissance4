public class Joueur {
	
	public String nom;
	public int nbVic;
	public Pion pion;
	
	public Joueur(String nom){
		this.nom=nom;
		this.nbVic=0;
	}
	
	public String getNom(){
		return nom;
	}
	
	public int getNbVic(){
		return nbVic;
	}
	
	public void addVic(){
		nbVic++;
	}
}

