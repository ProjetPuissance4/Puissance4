import java.awt.event.*;
import java.util.*;

public class EcouteurBouton2 implements ActionListener {
	private FenetreAccueil fen;
	
	public EcouteurBouton2(FenetreAccueil fen) {
		this.fen= fen;
	}
	public void actionPerformed(ActionEvent e) {
	
	
	} 
	
	
	}
	
