import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FenBidon extends JFrame{
	
	public FenBidon(FenetreAccueil fen) {
		super("Test");
		JLabel l1 = new JLabel("Ca a marché !!!!! ");
		this.add(l1);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(400,600);
		setVisible(true); 
		
	}
}

