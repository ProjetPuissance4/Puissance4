import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Pion {     
	public ImageIcon couleur ;     
	
	public Pion (ImageIcon c){
		this.couleur=c;
	}
	
}



