import java.awt.event.*;
import java.util.*;

public class EcouteurStart implements ActionListener {
	private FenetreAccueil fen;
	
	public EcouteurStart(FenetreAccueil fen) {
		this.fen= fen;
	}
	
	public void actionPerformed(ActionEvent e) {
		FenBidon f= new FenBidon(fen) ; 
		fen.fermeFen();

	}
}

