public class Puissance4 {
	
	public static void main(String[] a) {
		new FenetreAccueil();
	}
}
