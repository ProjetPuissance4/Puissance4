import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.*;
import java.awt.event.*;
import java.util.*;
import java.lang.Object.*;

public class TimerJeu extends Object {
	
	//attributs
	private FenetreJeu fen;	
	private int col;
	
	//constructeur
	public TimerJeu(int delay, FenetreJeu fen) {
		this.fen= fen;
		this.col = col;
	}
	
	
	public void actionPerformed(ActionEvent e) {
		fen.pion(col);
	} 
	
}
	
