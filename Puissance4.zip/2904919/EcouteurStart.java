import java.awt.event.*;
import java.util.*;

public class EcouteurStart implements ActionListener {
	//attributs
	private FenetreAccueil fen;
	
	//constructeur
	public EcouteurStart(FenetreAccueil fen) {
		this.fen= fen;
	}
	
	//lance le jeu
	public void actionPerformed(ActionEvent e) {
		
		//Vérifie que le nombre de caractères n'excède pas 10
		int taille;
		int taille2;
		if(fen.getNom1().length() < 10) {
			taille = fen.getNom1().length();
		}
		else {
			taille = 10;
		}
		if(fen.getNom2().length() < 10) {
			taille2 = fen.getNom2().length();
		}
		else {
			taille2 = 10;
		}
		fen.j1.setNom(fen.getNom1().substring(0,taille));
		if (fen.getNom1().equals(fen.getNom2())) {
			fen.j2.setNom(fen.getNom2().substring(0,taille2)+"bis");
		}
		else {
			fen.j2.setNom(fen.getNom2().substring(0,taille2));
		}
		if ( fen.condition() ) {
			FenetreJeu f = new FenetreJeu(fen, fen.j1, fen.j2) ; 		
			fen.fermeFen();
		}

	}
}

