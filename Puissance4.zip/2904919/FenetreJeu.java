import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.*;
import java.lang.*;
import java.lang.Thread;
import java.util.concurrent.TimeUnit;
import java.lang.Object.*;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import javax.swing.SwingUtilities;


public class FenetreJeu extends JFrame {
	//attributs
	public String[][] cases;
	public JButton[] flechesJeu = new JButton[7];
	public JPanel cadre;
	public JLabel haut;
	public boolean demarrer;
	public JLabel timer;
	public int[] tabJeu;
	public int nbCoup;
	public FenetreAccueil fAccueil;
	public JLabel[][] grille;
	public Joueur[] joueur;
	public ImageIcon fleche;
	public boolean etat;
	public int recherche;
	public int actuel;
	public long tempsEcouleDepuis;
	public Timer timerJeu;
	public int col; //colonne en cours
	public JPanel blanc;
	public String typeVictoire = ".";
	Temps t= new Temps();
    public JPanel chrono;
    public JButton annuler;
    public int[] dernierCoup;
    public int debut;
    public int fin;
	public int debut2;
	public FenetreVictoire vic;
	public String gagnant;


	
	//constructeur
	public FenetreJeu(FenetreAccueil f, Joueur j1, Joueur j2) {
		
		super("Puissance 4");
		
		fAccueil = f;
		nbCoup = 0;
		joueur = new Joueur[]{j1 , j2};
		this.setLayout(null);
		tabJeu = new int[]{0,0,0,0,0,0,0};
		demarrer = false;
		cases = new String[7][6];
		for (int i = 0 ; i < 7 ; i++) {
			for(int j = 0; j < 6 ; j++) {
				cases[i][j] = "blanc";
			}
		}
		
		//grille
		grille = new JLabel[2][42];
		for (int i = 0; i < 2 ; i++ ) {
			for(int j = 0; j < 42 ; j++) {
				grille[i][j] = new JLabel(joueur[i].getPion().getImage());
				grille[i][j].setSize(100,100);
			}
		}
		
		//Boutons des flèches, pour jouer
		fleche = new ImageIcon("fleche.png");
		setLocationRelativeTo(null);
		for(int i = 0; i < 7; i++) {
			flechesJeu[i] = new JButton("jouer à la ligne "+i, fleche);
			flechesJeu[i].addActionListener(new EcouteurFleche((this), i));
			flechesJeu[i].setLocation(290+i*100,790);
			flechesJeu[i].setSize(100,100);
			this.add(flechesJeu[i]);
		}
		//Textes du haut
		haut = new JLabel("C'est à "+joueur[nbCoup%2].getNom()+" de jouer ! ");
		haut.setFont(new Font("Elephant", Font.BOLD, 20));
		haut.setLocation(500,50);
		haut.setSize(800,50);
		this.add(haut);
		
		//affichage joueur1
		JLabel score1 = new JLabel(""+joueur[0].getNom() + " (" +joueur[0].getPion().getCouleur() +")");
		score1.setFont(new Font("Elephant", Font.BOLD, 20));
		score1.setSize(500,200);
		score1.setLocation(70, 300);
		this.add(score1);
		
		//score associé
		JLabel score11 = new JLabel("  "+joueur[0].getScore());
		score11.setFont(new Font("Elephant", Font.BOLD, 20));
		score11.setSize(100,100);
		score11.setLocation(100, 400);
		this.add(score11);
		
		//affichage joueur2
		JLabel score2 = new JLabel(""+joueur[1].getNom() + " (" +joueur[1].getPion().getCouleur() +")");
		score2.setFont(new Font("Elephant", Font.BOLD, 20));
		score2.setSize(500,200);
		score2.setLocation(1020, 300);
		this.add(score2);

		//score associé
		JLabel score22 = new JLabel("  "+joueur[1].getScore());
		score22.setFont(new Font("Elephant", Font.BOLD, 20));
		score22.setSize(100,100);
		score22.setLocation(1050, 400);
		this.add(score22);
		
		timerJeu = new Timer(10, new EcouteurTimerJeu(this));
		
		
		//fond
		blanc = new JPanel();
		blanc.setSize(700,600);
		blanc.setLocation(290,160);
		blanc.setBackground(Color.WHITE);
		
		//bouton annuler coup
		dernierCoup = new int[42];
		annuler = new JButton("Annuler coup");
		annuler.addActionListener(new EcouteurAnnuler((this)));
		annuler.setSize(150,100);
		annuler.setLocation(1050,600);

		

		this.validate();
		this.repaint();
		this.setSize(1400,1300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	
	//lignes de la grille
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.BLUE);
		g.drawLine(1000,200,1000,800);
		for (int i = 0; i <= 6 ; i++ ) {
			g.setColor(Color.BLUE);
			g.drawLine(300+i*100,200,300+i*100,800);
			g.drawLine(300,200+i*100,1000,200+i*100);
		}
		if (typeVictoire.equals("ligne")) {
			g.setColor(Color.BLACK);
			if (debut != 0) {
				g.drawLine(400+debut*100,250+(6-tabJeu[col])*100,300+(fin+1)*100,250+(6-tabJeu[col])*100);
			}
			else {
				g.drawLine(400+debut*100,250+(6-tabJeu[col])*100,300+(fin+1)*100,250+(6-tabJeu[col])*100);
			}
		}
		else if (typeVictoire.equals("colonne")) {
			g.setColor(Color.BLACK);
			if(debut != 0) {
				g.drawLine(350+col*100,200+(5-fin)*100,350+col*100,200+(5-debut)*100);
			}
			else {
				g.drawLine(350+col*100,200+(5-fin)*100,350+col*100,200+(6-debut)*100);
			}
		}
		else if (typeVictoire.equals("dgauche")) {
			g.setColor(Color.BLACK);

			if(fin != 0 && debut2 != 0) {
				g.drawLine(400+debut*100,300+(5-debut2)*100,300+fin*100,300+(5-debut2-4)*100);
			}
			else if (debut2 == 0) {
				g.drawLine(400+debut*100,300+(5-debut2)*100,300+fin*100,300+(5-debut2-4)*100);
			}
			else if (fin == 0) {
				g.drawLine(400+debut*100,300+(5-debut2)*100,300+fin*100,300+(5-debut2-4)*100);
			}
		}
		else if (typeVictoire.equals("ddroite")) {
			g.setColor(Color.BLACK);
			if(fin != 0 && debut2 != 0) {
				g.drawLine(300+debut*100,300+(5-debut2)*100,400+fin*100,300+(5-debut2-4)*100);
			}
			else if (debut2 == 0) {
				g.drawLine(300+debut*100,300+(5-debut2)*100,400+fin*100,300+(5-debut2-4)*100);
			}
			else if (fin == 0) {
				g.drawLine(300+debut*100,300+(5-debut2)*100,400+fin*100,300+(5-debut2-4)*100);
			}
		}
	}
	
		
	
	
	//faire un coup
	public void jouer(int i) {
		
		this.col = i;
		enleverBoutons();
		if ( nbCoup == 0 ) {
			this.getTemps();
		}
		
		if (tabJeu[col] == 6) {
			this.remove(flechesJeu[col]);
		}
		
		cases[col][tabJeu[col]] =  joueur[nbCoup%2].getPion().getCouleur();
		
		
		grille[nbCoup%2][nbCoup].setLocation(290+col*100,160);
		this.add(grille[nbCoup%2][nbCoup]);
		recherche = 160 + (50 - 10 * tabJeu[col]) * 10 ;
		actuel = 160;
		etat = true;
		tabJeu[col]++;
		timerJeu.start();
		this.remove(annuler);
		validate();
		repaint();
		
	}
	
	//vérifie si il y a une victoire ou pas
	public boolean testVictoire(){
		boolean test=false;
		
		if(testLigne() == true || testColonne() == true || testDiagoDroite() == true || testDiagoGauche() == true ){
			test=true;
		}
		else if(nbCoup == 41) {
			egalite();
		}
		return test;
			
	}
	
	//teste l'alignement de pions en ligne
	public boolean testLigne() {
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		debut = 0;
		for(int i = 0; i < 7; i++) {
			if( cases[i][tabJeu[col]-1].equals(c)) {
				compteur++;
			}
			
			else {
				debut = i;
				compteur = 0;
			}
			
			
			
			if( compteur == 4) {
				typeVictoire = "ligne";
				fin = i;
				break;
			}
		}
		return (compteur == 4);
	}
	
	//teste l'alignement de pions en colonne
	public boolean testColonne() {
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		debut = 0;
		for(int i = 0; i < 6; i++) {
			if( cases[col][i].equals(c)) {
				compteur++;
			}
			
			else {
				debut = i;
				compteur = 0;
			}
			
			
			
			if( compteur == 4) {
				fin = i;
				typeVictoire = "colonne";
				break;
			}
		}
		return (compteur == 4);
	}
	
	//teste l'alignement de pions en diagonale à gauche
	public boolean testDiagoGauche() {

		int co = col;
		int l = tabJeu[col] - 1;
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		while( co != 6 && l != 0) {
			co++;
			l--;
			debut = co;
			debut2 = l;
		}
		for(int i = 0 ; i <  6 ; i++) {
			try {
				if( cases[co-i][l+i].equals(c)) {
					compteur++;
				}
			
				else {
					debut = co-i-1;
					debut2 = l+i+1;
					compteur = 0;
				}
			
			
			
				if( compteur == 4) {
					fin = co-i;
					typeVictoire = "dgauche";
					break;
				}
			}
			
			catch(Exception ex) {
				System.out.print("");
			}
		}
		return (compteur == 4);
	}
	
	//teste l'alignement de pions en diagonale à droite
	public boolean testDiagoDroite() {

		int co = col;
		int l = tabJeu[col] - 1;
		int compteur = 0;
		String c = joueur[nbCoup%2].getPion().getCouleur();
		while( co !=  0 && l != 0) {
			co--;
			l--;
			debut = co;
			debut2 = l;
		}
		
		for(int i = 0 ; i <  6 ; i++) {
			try {
				if( cases[co+i][l+i].equals(c)) {
					compteur++;
				}
			
				else {
					debut = co+i+1;
					debut2 = l+i+1;
					compteur = 0;
				}
			
			
			
				if( compteur == 4) {
					fin = co+i;
					typeVictoire = "ddroite";
					break;
				}
			}
			
			catch(Exception ex) {
				System.out.print("");
			}
		}
		return (compteur == 4);
	}
	
	//lance les animations de victoire
	public void victoire() {
        t.stop();
        remove(chrono);
        
        gagnant=joueur[nbCoup%2].getNom();
        
		enleverBoutons();
		vic = new FenetreVictoire(this);
		
		joueur[nbCoup%2].addVic();
		haut.setText("BRAVO A "+joueur[nbCoup%2].getNom()+" POUR SA VICTOIRE !!");
		
		JButton rejouer = new JButton("REJOUER");
		JButton quitter = new JButton("QUITTER");
		
		rejouer.setSize(200,30);
		quitter.setSize(200,30);
		
		rejouer.setFont(new Font("Elephant", Font.BOLD, 20));
		quitter.setFont(new Font("Elephant", Font.BOLD, 20));
		
		rejouer.setLocation(400, 790);
		quitter.setLocation(700, 790);
		
		rejouer.addActionListener(new EcouteurFin((this), true));
		quitter.addActionListener(new EcouteurFin((this), false));		
		
		this.add(rejouer);
		this.add(quitter);
	}
	
	
	//pause
	public static void wait(int ms) {
										
		try {
		
			Thread.sleep(ms);
        
		}
    
		catch(InterruptedException ex) {
		
			Thread.currentThread().interrupt();
		}
	}
	
	//retourne l'état
	public boolean getEtat() {
		return etat;
	}
	
	public String getNomGagnant(){
		return gagnant;
	}
	
	
	//ajoute un pion
	public void pion() {
		if (actuel < recherche) {
			actuel = actuel + 10;
			this.remove(grille[nbCoup%2][nbCoup]);
			grille[nbCoup%2][nbCoup].setLocation(290+col*100,actuel);
			this.add(grille[nbCoup%2][nbCoup]);
			validate();
			repaint();
		}

		else {
			timerJeu.stop();
			mettreBoutons();
			if (tabJeu[col] == 6) {
				this.remove(flechesJeu[col]);
			}
			
			if (!testVictoire()) {
				dernierCoup[nbCoup] = col;
				this.add(annuler);
				nbCoup++;
				haut.setText("C'est à "+joueur[nbCoup%2].getNom()+" de jouer ! ");
				
			}
		
			else if (testVictoire()) {
				this.victoire();
			}
			
			
		}
	}
	
	//ajoute les boutons si la colonne n'est pas remplie
	public void mettreBoutons() {
		for(int i = 0 ; i < 7 ; i++) {
			if (tabJeu[i] != 6) {
				this.add(flechesJeu[i]);
			}
		}
		validate();
		repaint();
	}
	
	//enlève les boutons si la colonne est remplie
	public void enleverBoutons() {
		for(int i = 0; i < 7 ; i++) {
			this.remove(flechesJeu[i]);
		}
	}
	
	//retourne le chrono de la partie
	public void getTemps(){
        chrono = new JPanel();
        chrono=t.getPanel();
        chrono.setBounds(490, 20, 200, 40);
        this.add(chrono);
        t.start();
        this.validate();
        this.repaint();
    }
    
    public Temps getT(){
        return t;
    }
    
    //Méthode pour annuler le dernier coup
    public void annulerCoup() {
		nbCoup--;
		if (tabJeu[dernierCoup[nbCoup]] == 6) {
			this.add(flechesJeu[dernierCoup[nbCoup]]);
		}
		tabJeu[dernierCoup[nbCoup]]--;
		cases[dernierCoup[nbCoup]][tabJeu[dernierCoup[nbCoup]]] = "blanc";
		
		this.remove(grille[nbCoup%2][nbCoup]);
		if (nbCoup == 0) {
			this.remove(annuler);
		} 
		haut.setText("C'est à "+joueur[nbCoup%2].getNom()+" de jouer ! ");
		this.validate();
		this.repaint();
		
	}
	
	//Méthode en cas d'égalité
	public void egalite() {
		t.stop();
        remove(chrono);
        enleverBoutons();
        remove(annuler);
        
        haut.setText("EGALITE, FIN DE LA PARTIE");
		
		JButton rejouer = new JButton("REJOUER");
		JButton quitter = new JButton("QUITTER");
		
		rejouer.setSize(200,30);
		quitter.setSize(200,30);
		
		rejouer.setFont(new Font("Elephant", Font.BOLD, 20));
		quitter.setFont(new Font("Elephant", Font.BOLD, 20));
		
		rejouer.setLocation(400, 790);
		quitter.setLocation(700, 790);
		
		rejouer.addActionListener(new EcouteurFin((this), true));
		quitter.addActionListener(new EcouteurFin((this), false));
		
		this.add(rejouer);
		this.add(quitter);
		
		this.validate();
		this.repaint();
	}
	
	//Méthode qui permet de fermer la FenetreVictoire
	public void vicFin() {
		if (vic != null) {
			vic.dispose();
		}
	}

	
}
		





