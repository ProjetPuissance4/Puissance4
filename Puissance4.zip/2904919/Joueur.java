public class Joueur {
	//attributs
	public String nom;
	public int nbVic;
	public Pion pion;
	
	//constructeur
	public Joueur(){
		this.nbVic=0;
	}
	
	//récupérer le nom du joueur
	public String getNom(){
		return nom;
	}
	
	//attribuer un pion au joueur
	public void setPion(Pion p) {
		pion = p;
	}
	
	//attribuer un nom au joueur
	public void setNom(String n) {
		nom = n;
	}
	
	//récupérer le score du joueur
	public int getScore(){
		return nbVic;
	}
	
	//ajouter une victoire au score du joueur
	public void addVic(){
		nbVic++;
	}
	
	//récupérer le pion du joueur
	public Pion getPion() {
		return pion;
	}
}
