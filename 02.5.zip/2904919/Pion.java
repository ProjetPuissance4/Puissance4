import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.*;

public class Pion {     
	
	//attributs
	public String couleur;   
	public ImageIcon image;
	public ImageIcon[] images; 
	
	//constructeur
	public Pion (String c, int i){
		images = new ImageIcon[]{ new ImageIcon("jaune.png"), new ImageIcon("bleu.png") , new ImageIcon("rouge.png") , new ImageIcon("vert.png") } ;
		this.couleur=c;
		this.image = images[i];
	}
	
	//récupérer l'image du pion
	public ImageIcon getImage() {
		return image;
	}
	
	//récupérer la couleur du pion
	public String getCouleur() {
		return couleur;
	}
	
	
}
