import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.*;
import java.awt.event.*;
import java.util.*;
import java.lang.Object.*;

public class EcouteurAnnuler implements ActionListener {
	//attributs
	private FenetreJeu fen;	
	private int i;
	
	//constructeur
	public EcouteurAnnuler(FenetreJeu fen) {
		this.fen= fen;
	}
	
	//annuler le dernier coup
	public void actionPerformed(ActionEvent e) {
		fen.annulerCoup();
		fen.validate();
		fen.repaint();
	} 
	
}
	
