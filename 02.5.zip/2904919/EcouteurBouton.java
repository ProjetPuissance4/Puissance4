import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.io.*;
import java.awt.event.*;
import java.util.*;

public class EcouteurBouton implements ActionListener {
	
	//attributs
	private FenetreAccueil fen;
	private int i;
	private String color;
	
	//constructeur
	public EcouteurBouton(FenetreAccueil fen, int i, String color) {
		this.fen= fen;
		this.i=i;
		this.color = color;
	}
	
	//attribue au joueur son pion, et supprime le bouton de la couleur correspondantes pour l'autre joueur
	public void actionPerformed(ActionEvent e) {
		Pion p1 = new Pion(color, i);
		fen.j1.setPion(p1);
		fen.supprimeBouton(i);

	
	} 
	
	
	}
	
