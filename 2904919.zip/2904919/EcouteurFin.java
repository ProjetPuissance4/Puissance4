import java.awt.event.*;
import java.util.*;

public class EcouteurFin implements ActionListener {
	//attributs
	private FenetreJeu fen;
	private boolean rejouer;
	
	//constructeur
	public EcouteurFin(FenetreJeu fen, boolean rejouer) {
		this.fen= fen;
		this.rejouer = rejouer;
	}
	
	//relance la partie ou arrête le jeu
	public void actionPerformed(ActionEvent e) {
		if (rejouer) {
			fen.dispose();
			FenetreJeu f = new FenetreJeu(fen.fAccueil, fen.joueur[0], fen.joueur[1]);
			f.getTemps();
		}
		
		else {
			fen.dispose();
		}
	}
}

