import java.lang.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

public class Temps {
	
	private int heure=0;
	private int minute=0;
	private int seconde=0;
    private JPanel panel;
    private JLabel label;
   
    int delais=1000;
    ActionListener tache_timer;
    
   
    
    
    public Temps(){
        label = new JLabel(heure+":"+minute+":"+seconde); 
        panel = new JPanel(); 
    }
    
    
     public void start(){
        tache_timer= new ActionListener(){
            public void actionPerformed(ActionEvent e1){
                seconde++;
                if(seconde==60){
                    seconde=0;
                    minute++;
                }
                if(minute==60){
                    minute=0;
                    heure++;
                }
                label.setText(heure+":"+minute+":"+seconde);
            }
        };
        Timer timer= new Timer(delais,tache_timer);
        timer.start();
        label.setBorder(new EmptyBorder(20,140,20,20));
        panel.add(label,"Center");

    }
    
      public JPanel getPanel(){
        return panel;
    }
    
   /* public void stop(){
        timer.stop();
	}*/
}
