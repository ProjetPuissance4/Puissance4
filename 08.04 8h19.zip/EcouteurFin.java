import java.awt.event.*;
import java.util.*;

public class EcouteurFin implements ActionListener {
	private FenetreJeu fen;
	private boolean rejouer;
	
	public EcouteurFin(FenetreJeu fen, boolean rejouer) {
		this.fen= fen;
		this.rejouer = rejouer;
	}
	
	public void actionPerformed(ActionEvent e) {
		if (rejouer) {
			fen.dispose();
			FenetreJeu f = new FenetreJeu(fen.fAccueil, fen.joueur[0], fen.joueur[1]);
		}
		
		else {
			fen.dispose();
		}
	}
}

